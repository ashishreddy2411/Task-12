package classes;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dilukshan Mahendra
 */
public class Item {

   public String id;
   public String name;
   public int price;

    public Item(String a, String b, int c) {
        this.id = a;
        this.name = b;
        this.price = c;
    }
}
